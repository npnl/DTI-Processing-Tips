CONTENTS:
DTI_analysis_PC and DTI_notes_MAC are documents with detailed user notes for running DTI analyses in a variety of programs (DTI Studio for PC, and FSL and TrackVis for MACs). By Katarina, with instructions from An and Petya.

And the links for data analysis in DTI studio and DiffeoMap (used for the LDDMM, atlas-based analysis) are:
https://www.mristudio.org/wiki/user_manual/DTI_Studio_User_Manual
https://www.mristudio.org/wiki/user_manual/diffeomap
(from Petya Radoeva)